package com.cg.springdemothree.dto;

import java.util.List;

public class Employee implements EmployeeDetail{
     int empId;
     String empName;
    List<Project> pro;
	//Project proOne;
    //Project proTwo;
	public int getEmpId() {
		return empId;
	}

	public void setEmpId(int empId) {
		this.empId = empId;
	}

	public String getEmpName() {
		return empName;
	}

	public void setEmpName(String empName) {
		this.empName = empName;
	}

	public List<Project> getPro() {
		return pro;
	}

	public void setPro(List<Project> pro) {
		this.pro = pro;
	}

 /*	@Override
	public void getAllEmployeeDetail() {
		System.out.println("EmpId is:"+empId);
		System.out.println("EmpName is:"+empName);
		
		System.out.println("ProjectOne Id is:"+proOne.getProjId());
		System.out.println("ProjectOne Name is:"+proOne.getProjName());
		
		System.out.println("ProjectTwo Id is:"+proTwo.getProjId());
		System.out.println("ProjectTwo Name is:"+proTwo.getProjName());
	}*/
     
	@Override
	public void getAllEmployeeDetail() {
		System.out.println("EmpId is:"+empId);
		System.out.println("EmpName is:"+empName);
		for(Project project:pro){
			System.out.println("Project Id is "+project.getProjId());
			System.out.println("Project Name is "+project.getProjName());
		}
	}
}
