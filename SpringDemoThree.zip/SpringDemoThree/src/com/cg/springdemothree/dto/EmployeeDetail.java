package com.cg.springdemothree.dto;

public interface EmployeeDetail {
       public void getAllEmployeeDetail();
}
