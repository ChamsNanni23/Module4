package com.cg.spel.ui;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.cg.spel.dto.PrintEmployeedetail;



public class MyTest {
	public static void main(String[] args) {
		ApplicationContext app=new ClassPathXmlApplicationContext("spring.xml");
		PrintEmployeedetail e =(PrintEmployeedetail) app.getBean("print");
		e.getAllDetail();
	}

}
