package com.cg.springdemotwo.dto;

public class Employee implements EmployeeDetail{
     int empId;
     String empName;
     
	public Employee() {
	
	}

	public Employee(int empId, String empName) {
	
		this.empId = empId;
		this.empName = empName;
	}

	@Override
	public void getAllEmployeeDetail() 
	{
		System.out.println("Id is:"+empId);
		System.out.println("Name is:"+empName);
	}

}
