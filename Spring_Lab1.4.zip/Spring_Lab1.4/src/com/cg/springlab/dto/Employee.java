package com.cg.springlab.dto;

public class Employee {
     int empId;
     String empName;
     double empsal;
	public int getEmpId() {
		return empId;
	}
	public void setEmpId(int empId) {
		this.empId = empId;
	}
	public String getEmpName() {
		return empName;
	}
	public void setEmpName(String empName) {
		this.empName = empName;
	}
	public double getEmpsal() {
		return empsal;
	}
	public void setEmpsal(double empsal) {
		this.empsal = empsal;
	}
	public void getAllDetails(){
		   System.out.println("Employee Id is:"+empId+"\nEmployee name is:"+empName+"\nEmployee salary is:"+empsal);
}
}
