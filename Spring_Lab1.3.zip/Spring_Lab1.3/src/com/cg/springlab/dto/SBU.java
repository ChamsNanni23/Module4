package com.cg.springlab.dto;

import java.util.List;

import com.cg.springlab.dto.Employee;

public class SBU {
	String sbuCode;
	String sbuHead;
	String sbuName;
	List<Employee> emp;
	public String getSbuCode() {
		return sbuCode;
	}
	public void setSbuCode(String sbuCode) {
		this.sbuCode = sbuCode;
	}
	public String getSbuHead() {
		return sbuHead;
	}
	public void setSbuHead(String sbuHead) {
		this.sbuHead = sbuHead;
	}
	public String getSbuName() {
		return sbuName;
	}
	public void setSbuName(String sbuName) {
		this.sbuName = sbuName;
	}
	public List<Employee> getEmp() {
		return emp;
	}
	public void setEmp(List<Employee> emp) {
		this.emp = emp;
	}
	
	
	public void getSBUDetail() {
		System.out.println("sbu details"+"[sbuCode="+sbuCode+","
                 +" sbuHead="+sbuHead+","
                 +" sbuName="+sbuName+"]");
		for(Employee employee:emp){
			System.out.println("Employee"+"[empAge="+employee.getAge()+","
		                                 +" empId="+employee.getEmpId()+","
                                         +" empName="+employee.getEmpName()+","
		                                 +" empSalary="+employee.getEmpsal()+"]");
		}
}
}
