package com.cg.springlab.dto;

public interface SBUDetail {
    public void getSBUDetail();
}
