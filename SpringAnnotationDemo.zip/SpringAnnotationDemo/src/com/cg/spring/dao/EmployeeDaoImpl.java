package com.cg.spring.dao;

import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.stereotype.Repository;

@Repository("employeedao")
public class EmployeeDaoImpl implements EmployeeDao {
   
	@Override
	public void getData() {
		System.out.println("In dao layer");
		
	}

}
