package com.cg.spring.dao;

public interface EmployeeDao {
     public void getData();
}
