package com.cg.spring.dto;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.cg.spring.dao.EmployeeDao;
import com.cg.spring.service.EmployeeService;

@Component("emp")
public class Employee {
	@Autowired
	EmployeeService employeeservice;
	@Autowired
	EmployeeDao employeedao;
	public void getDetails(){
    	   System.out.println("Welcome to spring");
    	   employeeservice.getData();
    	   employeedao.getData();
       }
}
