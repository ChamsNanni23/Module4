package com.cg.spring.service;

import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;

@Service("employeeservice")
public class EmployeeServiceImpl implements EmployeeService {

	@Override
	public void getData() {
		System.out.println("In service");
		
	}

	

}
