package com.cg.spring.service;

public interface EmployeeService {
      public void getData();
    	  
      
}
