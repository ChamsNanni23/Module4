package com.cg.springlab2.controller;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.cg.springlab2.dto.Trainee;
import com.cg.springlab2.service.ITraineeService;



@Controller
public class MyController 
{
	@Autowired
	ITraineeService traineeservice;


	@RequestMapping(value="all",method=RequestMethod.GET)
	public String getAll()
	{
		return "login";
	}
	
	@RequestMapping(value="home",method=RequestMethod.GET)
	public String getHome()
	{
		return "home";
	}
	
	@RequestMapping(value="add",method=RequestMethod.GET)
	public String addTrainee(@ModelAttribute("my") Trainee tra,
			Map<String,Object> model) 
	{
		List<String> myDom=new ArrayList<>();
		myDom.add("Java");
		myDom.add("VnV");
		myDom.add("dotNet");
		model.put("dom", myDom);
		return "addtrainee";
	}

	@RequestMapping(value="insertdata",method=RequestMethod.POST)
	public ModelAndView insertTrainee(@Valid @ModelAttribute("my") Trainee tra, 
			BindingResult result , Map<String,Object> model)
	{
		//		System.out.println("Name is "+emp.getTraName());
		int id;
		if(result.hasErrors())
		{
			List<String> myDom=new ArrayList<>();
		    myDom.add("Java");
		    myDom.add("VnV");
		    myDom.add("dotNet");
		    model.put("dom", myDom);
			return new ModelAndView("addtrainee");
		}
		else
		{
	        id=traineeservice.addTraineeData(tra);
		} 
		return new ModelAndView("sucess","edata",id);
	}

	@RequestMapping(value="delete", method=RequestMethod.GET)
	public String deleteTrainee()
	{
		return "deletetrainee";
	}

	@RequestMapping(value="dodelete", method=RequestMethod.GET)
	public String traineeDelete(@RequestParam("tid") int id)
	{
		//System.out.println("Id is...."+id);
		traineeservice.deleteTrainee(id);
		return "deletesucess";
	}
	
	@RequestMapping(value="view",method=RequestMethod.GET)
	public ModelAndView viewAll(){
		List<Trainee> myAllData = traineeservice.viewAll();
		return new ModelAndView("viewall","temp",myAllData);
	}
	
	@RequestMapping(value="searchid", method=RequestMethod.GET)
	public String searchTrainee(){
		return "searchid";
	}
	
	@RequestMapping(value="searchidd",method=RequestMethod.GET)
	public ModelAndView searchTrainee(@RequestParam("tid")int id){
		List<Trainee> myAllData= traineeservice.searchTrainee(id);
		return new ModelAndView("searchsuccess","temp",myAllData);
	}
	@RequestMapping(value="modify",method=RequestMethod.GET)
	public String modifyData()
	{
		return "modifyform";
	}
	@RequestMapping(value="updatetrainee",method=RequestMethod.GET)
	public ModelAndView TraineeModify(@RequestParam("myid") int myid,@ModelAttribute("my") Trainee trainee)
	{
		System.out.println("id is"+myid);
		List<Trainee> mymodifyData=traineeservice.searchTrainee(myid);
		return new ModelAndView("modifyform","temp2",mymodifyData);
	}
	@RequestMapping(value="updated",method=RequestMethod.POST)
	public String traineeupdated(@ModelAttribute("my")Trainee trainee)
	{
		System.out.println("Hii");
		traineeservice.updateTrainee(trainee);
		return "successupdate";
	}
//	@RequestMapping(value="dodelete", method=RequestMethod.GET)
//	public String traineeDelete(@RequestParam("tid") int id)
//	{
//		//System.out.println("Id is...."+id);
//		traineeservice.deleteTrainee(id);
//		return "deletesucess";
//	}
	
	}



