package com.cg.springlab2.service;

import java.util.List;

import com.cg.springlab2.dto.Trainee;


public interface ITraineeService 
{
	public int addTraineeData(Trainee tra);

	public void deleteTrainee(int traId);
	
	public List<Trainee> viewAll();
	
	public List<Trainee> searchTrainee(int traId);
	public Trainee updateTrainee(Trainee trainee);
}
